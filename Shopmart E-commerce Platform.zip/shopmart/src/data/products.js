const products = [
  { id: 1, name: "Minimal Desk Lamp", price: 49.99, category: "Home", image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop", description: "A sleek, adjustable LED desk lamp with touch dimmer and USB charging port. Perfect for focused work sessions." },
  { id: 2, name: "Linen Notebook", price: 18.99, category: "Stationery", image: "https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=400&h=400&fit=crop", description: "Premium linen-covered notebook with 200 acid-free pages. Lay-flat binding for comfortable writing." },
  { id: 3, name: "Ceramic Mug", price: 24.99, category: "Kitchen", image: "https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=400&h=400&fit=crop", description: "Handcrafted ceramic mug, microwave and dishwasher safe. 350ml capacity." },
  { id: 4, name: "Wooden Watch", price: 89.99, category: "Accessories", image: "https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=400&h=400&fit=crop", description: "Eco-friendly bamboo watch with Japanese quartz movement. Lightweight and water-resistant." },
  { id: 5, name: "Canvas Tote Bag", price: 32.99, category: "Accessories", image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=400&h=400&fit=crop", description: "Heavy-duty organic cotton canvas tote. 15L capacity, reinforced handles." },
  { id: 6, name: "Plant Pot Set", price: 39.99, category: "Home", image: "https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=400&h=400&fit=crop", description: "Set of 3 minimalist concrete plant pots with drainage holes. Sizes: S/M/L." },
  { id: 7, name: "Wireless Earbuds", price: 79.99, category: "Tech", image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?w=400&h=400&fit=crop", description: "True wireless earbuds with 24hr battery life and active noise cancellation." },
  { id: 8, name: "Scented Candle", price: 22.99, category: "Home", image: "https://images.unsplash.com/photo-1602874801007-bd458bb1b8b6?w=400&h=400&fit=crop", description: "Soy wax candle with cedarwood and vanilla scent. 40-hour burn time." },
  { id: 9, name: "Leather Wallet", price: 44.99, category: "Accessories", image: "https://images.unsplash.com/photo-1627123424574-724758594e93?w=400&h=400&fit=crop", description: "Slim full-grain leather bifold wallet. 6 card slots and a bill compartment." },
  { id: 10, name: "Pen Set", price: 14.99, category: "Stationery", image: "https://images.unsplash.com/photo-1583485088034-697b5bc54ccd?w=400&h=400&fit=crop", description: "Set of 5 fine-tip ballpoint pens in assorted neutral colors. Smooth gel ink." },
  { id: 11, name: "Bluetooth Speaker", price: 59.99, category: "Tech", image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=400&h=400&fit=crop", description: "Portable speaker with 360° sound, IPX5 waterproof rating, 12hr battery." },
  { id: 12, name: "Knit Throw Blanket", price: 54.99, category: "Home", image: "https://images.unsplash.com/photo-1586105251261-72a756497a11?w=400&h=400&fit=crop", description: "Chunky knit throw in 100% merino wool. 130×160cm, available in 4 colors." },
];

export default products;
