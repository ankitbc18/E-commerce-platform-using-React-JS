import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Catalog from './pages/Catalog';
import ProductDetail from './pages/ProductDetail';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Login from './pages/Login';
import useCart from './hooks/useCart';
import useAuth from './hooks/useAuth';

export default function App() {
  const { cart, addToCart, removeFromCart, updateQty, clearCart, totalItems, totalPrice } = useCart();
  const { user, login, signup, logout } = useAuth();

  return (
    <Router>
      <div style={{ minHeight: '100vh', background: '#F9F9F7', fontFamily: "'Inter', sans-serif" }}>
        <Navbar totalItems={totalItems} user={user} onLogout={logout} />
        <Routes>
          <Route path="/" element={<Home onAddToCart={addToCart} />} />
          <Route path="/catalog" element={<Catalog onAddToCart={addToCart} />} />
          <Route path="/product/:id" element={<ProductDetail onAddToCart={addToCart} />} />
          <Route path="/cart" element={<Cart cart={cart} onRemove={removeFromCart} onUpdateQty={updateQty} totalPrice={totalPrice} />} />
          <Route path="/checkout" element={<Checkout cart={cart} totalPrice={totalPrice} onClearCart={clearCart} />} />
          <Route path="/login" element={<Login onLogin={login} onSignup={signup} />} />
        </Routes>
        <footer style={{ textAlign: 'center', padding: '32px', color: '#AAA', fontSize: '13px', borderTop: '1px solid #EBEBEB', marginTop: '40px' }}>
          © 2025 Shopmart — A React Course Project
        </footer>
      </div>
    </Router>
  );
}
