import { useState, useEffect } from 'react';

const USERS_KEY = 'shopmart-users';
const SESSION_KEY = 'shopmart-session';

export default function useAuth() {
  const [user, setUser] = useState(() => {
    const saved = localStorage.getItem(SESSION_KEY);
    return saved ? JSON.parse(saved) : null;
  });

  useEffect(() => {
    if (user) localStorage.setItem(SESSION_KEY, JSON.stringify(user));
    else localStorage.removeItem(SESSION_KEY);
  }, [user]);

  const getUsers = () => {
    const saved = localStorage.getItem(USERS_KEY);
    return saved ? JSON.parse(saved) : [];
  };

  const login = (email, password) => {
    const users = getUsers();
    const match = users.find(u => u.email.toLowerCase() === email.toLowerCase() && u.password === password);
    if (!match) return { ok: false, error: 'Incorrect email or password' };
    setUser({ name: match.name, email: match.email });
    return { ok: true };
  };

  const signup = (name, email, password) => {
    const users = getUsers();
    if (users.some(u => u.email.toLowerCase() === email.toLowerCase())) {
      return { ok: false, error: 'An account with that email already exists' };
    }
    const newUsers = [...users, { name, email, password }];
    localStorage.setItem(USERS_KEY, JSON.stringify(newUsers));
    setUser({ name, email });
    return { ok: true };
  };

  const logout = () => setUser(null);

  return { user, login, signup, logout };
}
