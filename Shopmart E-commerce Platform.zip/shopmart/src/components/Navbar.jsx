import { Link, useLocation } from 'react-router-dom';

export default function Navbar({ totalItems, user, onLogout }) {
  const location = useLocation();

  return (
    <nav style={styles.nav}>
      <Link to="/" style={styles.brand}>Shopmart</Link>
      <div style={styles.links}>
        <Link to="/catalog" style={{ ...styles.link, ...(location.pathname === '/catalog' ? styles.active : {}) }}>Shop</Link>
        {user ? (
          <div style={styles.userMenu}>
            <span style={styles.userName}>Hi, {user.name.split(' ')[0]}</span>
            <button onClick={onLogout} style={styles.logoutBtn}>Log out</button>
          </div>
        ) : (
          <Link to="/login" style={{ ...styles.link, ...(location.pathname === '/login' ? styles.active : {}) }}>Login</Link>
        )}
        <Link to="/cart" style={styles.cartBtn}>
          Cart {totalItems > 0 && <span style={styles.badge}>{totalItems}</span>}
        </Link>
      </div>
    </nav>
  );
}

const styles = {
  nav: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '18px 48px', borderBottom: '1px solid #E5E5E5', background: '#F9F9F7', position: 'sticky', top: 0, zIndex: 100 },
  brand: { fontFamily: "'Playfair Display', serif", fontSize: '22px', fontWeight: '700', color: '#1A1A1A', textDecoration: 'none', letterSpacing: '-0.5px' },
  links: { display: 'flex', alignItems: 'center', gap: '28px' },
  link: { color: '#555', textDecoration: 'none', fontSize: '14px', fontWeight: '500', transition: 'color 0.2s' },
  active: { color: '#1A1A1A', borderBottom: '1.5px solid #1A1A1A', paddingBottom: '2px' },
  cartBtn: { background: '#1A1A1A', color: '#fff', padding: '9px 20px', borderRadius: '6px', textDecoration: 'none', fontSize: '14px', fontWeight: '500', display: 'flex', alignItems: 'center', gap: '8px' },
  badge: { background: '#4A6FA5', borderRadius: '50%', width: '20px', height: '20px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '11px', fontWeight: '700' },
  userMenu: { display: 'flex', alignItems: 'center', gap: '14px' },
  userName: { fontSize: '14px', fontWeight: '600', color: '#1A1A1A' },
  logoutBtn: { background: 'none', border: '1.5px solid #E0E0E0', borderRadius: '6px', padding: '7px 14px', fontSize: '13px', fontWeight: '600', color: '#555', cursor: 'pointer' },
};
