import { Link } from 'react-router-dom';

export default function ProductCard({ product, onAddToCart }) {
  return (
    <div style={styles.card}>
      <Link to={`/product/${product.id}`} style={{ textDecoration: 'none' }}>
        <div style={styles.imgWrap}>
          <img src={product.image} alt={product.name} style={styles.img} />
          <span style={styles.category}>{product.category}</span>
        </div>
        <div style={styles.info}>
          <p style={styles.name}>{product.name}</p>
          <p style={styles.price}>${product.price.toFixed(2)}</p>
        </div>
      </Link>
      <button style={styles.btn} onClick={() => onAddToCart(product)}
        onMouseEnter={e => e.target.style.background = '#3a5a8a'}
        onMouseLeave={e => e.target.style.background = '#4A6FA5'}>
        Add to Cart
      </button>
    </div>
  );
}

const styles = {
  card: { background: '#fff', borderRadius: '10px', overflow: 'hidden', border: '1px solid #EBEBEB', display: 'flex', flexDirection: 'column' },
  imgWrap: { position: 'relative', aspectRatio: '1', overflow: 'hidden' },
  img: { width: '100%', height: '100%', objectFit: 'cover', transition: 'transform 0.3s ease' },
  category: { position: 'absolute', top: '10px', left: '10px', background: 'rgba(255,255,255,0.9)', padding: '3px 10px', borderRadius: '20px', fontSize: '11px', color: '#555', fontWeight: '500' },
  info: { padding: '14px 16px 8px' },
  name: { margin: '0 0 6px', fontSize: '15px', fontWeight: '600', color: '#1A1A1A' },
  price: { margin: 0, fontSize: '15px', color: '#4A6FA5', fontWeight: '700' },
  btn: { margin: '8px 16px 16px', padding: '10px', background: '#4A6FA5', color: '#fff', border: 'none', borderRadius: '6px', fontSize: '13px', fontWeight: '600', cursor: 'pointer', transition: 'background 0.2s' },
};
