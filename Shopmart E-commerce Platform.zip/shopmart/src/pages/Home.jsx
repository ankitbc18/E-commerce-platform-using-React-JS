import { Link } from 'react-router-dom';
import products from '../data/products';
import ProductCard from '../components/ProductCard';

export default function Home({ onAddToCart }) {
  const featured = products.slice(0, 3);

  return (
    <div>
      {/* Hero */}
      <section style={styles.hero}>
        <div style={styles.heroContent}>
          <p style={styles.eyebrow}>Curated goods for intentional living</p>
          <h1 style={styles.heroTitle}>Things worth<br />owning.</h1>
          <p style={styles.heroSub}>A carefully selected catalog of minimal, well-made products for everyday life.</p>
          <Link to="/catalog" style={styles.heroBtn}>Browse the Catalog</Link>
        </div>
        <div style={styles.heroRight}>
          <img src="https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=600&h=500&fit=crop" alt="hero" style={styles.heroImg} />
        </div>
      </section>

      {/* Categories */}
      <section style={styles.section}>
        <h2 style={styles.sectionTitle}>Shop by Category</h2>
        <div style={styles.catGrid}>
          {['Home', 'Accessories', 'Stationery', 'Tech', 'Kitchen'].map(cat => (
            <Link to={`/catalog?category=${cat}`} key={cat} style={styles.catCard}>
              <span style={styles.catLabel}>{cat}</span>
            </Link>
          ))}
        </div>
      </section>

      {/* Featured */}
      <section style={styles.section}>
        <h2 style={styles.sectionTitle}>Featured Products</h2>
        <div style={styles.grid}>
          {featured.map(p => <ProductCard key={p.id} product={p} onAddToCart={onAddToCart} />)}
        </div>
        <div style={{ textAlign: 'center', marginTop: '32px' }}>
          <Link to="/catalog" style={styles.outlineBtn}>View All Products</Link>
        </div>
      </section>
    </div>
  );
}

const styles = {
  hero: { display: 'flex', alignItems: 'center', gap: '48px', padding: '64px 48px', background: '#F9F9F7', minHeight: '480px' },
  heroContent: { flex: 1 },
  eyebrow: { color: '#4A6FA5', fontSize: '13px', fontWeight: '600', letterSpacing: '0.05em', marginBottom: '16px', textTransform: 'uppercase' },
  heroTitle: { fontFamily: "'Playfair Display', serif", fontSize: 'clamp(42px, 6vw, 72px)', fontWeight: '700', color: '#1A1A1A', lineHeight: 1.1, margin: '0 0 20px' },
  heroSub: { color: '#666', fontSize: '17px', lineHeight: 1.6, maxWidth: '420px', margin: '0 0 32px' },
  heroBtn: { display: 'inline-block', background: '#1A1A1A', color: '#fff', padding: '14px 32px', borderRadius: '8px', textDecoration: 'none', fontSize: '15px', fontWeight: '600' },
  heroRight: { flex: 1, borderRadius: '16px', overflow: 'hidden', maxWidth: '500px' },
  heroImg: { width: '100%', height: '380px', objectFit: 'cover' },
  section: { padding: '56px 48px' },
  sectionTitle: { fontFamily: "'Playfair Display', serif", fontSize: '28px', fontWeight: '700', color: '#1A1A1A', marginBottom: '32px' },
  catGrid: { display: 'flex', gap: '12px', flexWrap: 'wrap' },
  catCard: { padding: '12px 28px', border: '1.5px solid #DDDDE0', borderRadius: '40px', textDecoration: 'none', color: '#333', fontSize: '14px', fontWeight: '500', transition: 'all 0.2s', background: '#fff' },
  catLabel: { fontWeight: '600' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))', gap: '24px' },
  outlineBtn: { display: 'inline-block', border: '1.5px solid #1A1A1A', color: '#1A1A1A', padding: '13px 36px', borderRadius: '8px', textDecoration: 'none', fontSize: '14px', fontWeight: '600' },
};
