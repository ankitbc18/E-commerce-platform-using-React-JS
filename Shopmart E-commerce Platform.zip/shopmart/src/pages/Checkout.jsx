import { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Checkout({ cart, totalPrice, onClearCart }) {
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', address: '', city: '', card: '', expiry: '', cvv: '' });
  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Name is required';
    if (!form.email.includes('@')) e.email = 'Valid email required';
    if (!form.address.trim()) e.address = 'Address is required';
    if (!form.city.trim()) e.city = 'City is required';
    if (form.card.replace(/\s/g, '').length < 16) e.card = 'Enter a valid 16-digit card number';
    if (!form.expiry.match(/^\d{2}\/\d{2}$/)) e.expiry = 'Format MM/YY';
    if (form.cvv.length < 3) e.cvv = 'Enter 3-digit CVV';
    return e;
  };

  const handleChange = (field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors(prev => ({ ...prev, [field]: '' }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }
    setSubmitted(true);
    onClearCart();
    setTimeout(() => navigate('/'), 3000);
  };

  if (submitted) return (
    <div style={styles.success}>
      <div style={styles.successIcon}>✓</div>
      <h2 style={styles.successTitle}>Order Placed!</h2>
      <p style={styles.successSub}>Thanks for your order. Redirecting you home...</p>
    </div>
  );

  if (cart.length === 0) { navigate('/catalog'); return null; }

  const Field = ({ label, field, placeholder, type = 'text' }) => (
    <div style={styles.field}>
      <label style={styles.label}>{label}</label>
      <input type={type} placeholder={placeholder} value={form[field]}
        onChange={e => handleChange(field, e.target.value)}
        style={{ ...styles.input, ...(errors[field] ? styles.inputErr : {}) }} />
      {errors[field] && <p style={styles.errMsg}>{errors[field]}</p>}
    </div>
  );

  return (
    <div style={styles.page}>
      <h1 style={styles.title}>Checkout</h1>
      <div style={styles.layout}>
        <form onSubmit={handleSubmit} style={styles.form}>
          <h3 style={styles.section}>Shipping Details</h3>
          <Field label="Full Name" field="name" placeholder="John Doe" />
          <Field label="Email" field="email" placeholder="john@email.com" type="email" />
          <Field label="Street Address" field="address" placeholder="123 Main St" />
          <Field label="City" field="city" placeholder="Kathmandu" />

          <h3 style={{ ...styles.section, marginTop: '28px' }}>Payment</h3>
          <Field label="Card Number" field="card" placeholder="1234 5678 9012 3456" />
          <div style={styles.row}>
            <Field label="Expiry" field="expiry" placeholder="MM/YY" />
            <Field label="CVV" field="cvv" placeholder="123" />
          </div>

          <button type="submit" style={styles.placeBtn}>Place Order — ${totalPrice.toFixed(2)}</button>
        </form>

        <div style={styles.orderSide}>
          <h3 style={styles.section}>Your Order</h3>
          {cart.map(item => (
            <div key={item.id} style={styles.orderItem}>
              <img src={item.image} alt={item.name} style={styles.orderImg} />
              <div style={{ flex: 1 }}>
                <p style={styles.itemName}>{item.name}</p>
                <p style={styles.itemQty}>Qty: {item.qty}</p>
              </div>
              <span style={styles.itemPrice}>${(item.price * item.qty).toFixed(2)}</span>
            </div>
          ))}
          <div style={styles.orderTotal}>
            <span style={{ fontWeight: '700' }}>Total</span>
            <span style={{ fontWeight: '700', color: '#4A6FA5' }}>${totalPrice.toFixed(2)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: { padding: '40px 48px' },
  title: { fontFamily: "'Playfair Display', serif", fontSize: '32px', fontWeight: '700', color: '#1A1A1A', marginBottom: '32px' },
  layout: { display: 'flex', gap: '48px', alignItems: 'flex-start' },
  form: { flex: 3 },
  section: { fontSize: '17px', fontWeight: '700', color: '#1A1A1A', marginBottom: '16px', marginTop: 0 },
  field: { marginBottom: '16px' },
  label: { display: 'block', fontSize: '13px', fontWeight: '600', color: '#555', marginBottom: '6px' },
  input: { width: '100%', padding: '11px 14px', border: '1.5px solid #E0E0E0', borderRadius: '8px', fontSize: '14px', outline: 'none', boxSizing: 'border-box', background: '#fff' },
  inputErr: { borderColor: '#E53935' },
  errMsg: { color: '#E53935', fontSize: '12px', margin: '4px 0 0' },
  row: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' },
  placeBtn: { width: '100%', padding: '15px', background: '#4A6FA5', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '16px', fontWeight: '700', cursor: 'pointer', marginTop: '24px' },
  orderSide: { flex: 2, background: '#fff', border: '1px solid #EBEBEB', borderRadius: '12px', padding: '24px', position: 'sticky', top: '80px' },
  orderItem: { display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' },
  orderImg: { width: '52px', height: '52px', objectFit: 'cover', borderRadius: '8px' },
  itemName: { margin: '0 0 4px', fontSize: '14px', fontWeight: '600', color: '#1A1A1A' },
  itemQty: { margin: 0, fontSize: '12px', color: '#888' },
  itemPrice: { fontWeight: '700', color: '#4A6FA5', fontSize: '14px' },
  orderTotal: { display: 'flex', justifyContent: 'space-between', borderTop: '1px solid #EBEBEB', paddingTop: '16px', marginTop: '8px', fontSize: '17px' },
  success: { textAlign: 'center', padding: '120px 48px' },
  successIcon: { width: '72px', height: '72px', background: '#E8F5E9', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '32px', color: '#2E7D32', margin: '0 auto 20px' },
  successTitle: { fontFamily: "'Playfair Display', serif", fontSize: '32px', color: '#1A1A1A', margin: '0 0 12px' },
  successSub: { color: '#888', fontSize: '16px' },
};
