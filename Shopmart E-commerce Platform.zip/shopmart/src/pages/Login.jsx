import { useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';

// Defined OUTSIDE Login so it isn't recreated on every keystroke/re-render,
// which was causing the input to lose focus after each character typed.
function Field({ label, field, placeholder, type = 'text', value, error, onChange }) {
  return (
    <div style={styles.field}>
      <label style={styles.label}>{label}</label>
      <input
        type={type}
        placeholder={placeholder}
        value={value}
        onChange={e => onChange(field, e.target.value)}
        style={{ ...styles.input, ...(error ? styles.inputErr : {}) }}
      />
      {error && <p style={styles.errMsg}>{error}</p>}
    </div>
  );
}

export default function Login({ onLogin, onSignup }) {
  const navigate = useNavigate();
  const location = useLocation();
  const from = location.state?.from || '/';

  const [mode, setMode] = useState('login'); // 'login' | 'signup'
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');

  const handleChange = (field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
    if (errors[field]) setErrors(prev => ({ ...prev, [field]: '' }));
    if (formError) setFormError('');
  };

  const validate = () => {
    const e = {};
    if (mode === 'signup' && !form.name.trim()) e.name = 'Name is required';
    if (!form.email.includes('@')) e.email = 'Valid email required';
    if (form.password.length < 6) e.password = 'At least 6 characters';
    return e;
  };

  const handleSubmit = (ev) => {
    ev.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length > 0) { setErrors(errs); return; }

    const result = mode === 'login'
      ? onLogin(form.email, form.password)
      : onSignup(form.name, form.email, form.password);

    if (!result.ok) { setFormError(result.error); return; }
    navigate(from, { replace: true });
  };

  return (
    <div style={styles.page}>
      <div style={styles.card}>
        <h1 style={styles.title}>{mode === 'login' ? 'Welcome back' : 'Create your account'}</h1>
        <p style={styles.subtitle}>
          {mode === 'login' ? 'Sign in to continue to Shopmart.' : 'Join Shopmart to check out faster.'}
        </p>

        <form onSubmit={handleSubmit} style={styles.form}>
          {mode === 'signup' && (
            <Field label="Full Name" field="name" placeholder="John Doe"
              value={form.name} error={errors.name} onChange={handleChange} />
          )}
          <Field label="Email" field="email" placeholder="john@email.com" type="email"
            value={form.email} error={errors.email} onChange={handleChange} />
          <Field label="Password" field="password" placeholder="••••••••" type="password"
            value={form.password} error={errors.password} onChange={handleChange} />

          {formError && <p style={styles.formErr}>{formError}</p>}

          <button type="submit" style={styles.submitBtn}>
            {mode === 'login' ? 'Sign In' : 'Sign Up'}
          </button>
        </form>

        <p style={styles.switchText}>
          {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
          <button
            type="button"
            style={styles.switchBtn}
            onClick={() => { setMode(mode === 'login' ? 'signup' : 'login'); setErrors({}); setFormError(''); }}
          >
            {mode === 'login' ? 'Sign up' : 'Sign in'}
          </button>
        </p>

        <Link to="/" style={styles.backLink}>← Back to home</Link>
      </div>
    </div>
  );
}

const styles = {
  page: { minHeight: 'calc(100vh - 140px)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '48px 24px' },
  card: { width: '100%', maxWidth: '400px', background: '#fff', border: '1px solid #EBEBEB', borderRadius: '12px', padding: '40px 36px' },
  title: { fontFamily: "'Playfair Display', serif", fontSize: '28px', fontWeight: '700', color: '#1A1A1A', margin: '0 0 8px' },
  subtitle: { color: '#888', fontSize: '14px', margin: '0 0 28px' },
  form: { display: 'flex', flexDirection: 'column' },
  field: { marginBottom: '16px' },
  label: { display: 'block', fontSize: '13px', fontWeight: '600', color: '#555', marginBottom: '6px' },
  input: { width: '100%', padding: '11px 14px', border: '1.5px solid #E0E0E0', borderRadius: '8px', fontSize: '14px', outline: 'none', boxSizing: 'border-box', background: '#fff' },
  inputErr: { borderColor: '#E53935' },
  errMsg: { color: '#E53935', fontSize: '12px', margin: '4px 0 0' },
  formErr: { color: '#E53935', fontSize: '13px', background: '#FDECEA', border: '1px solid #F5C6C3', borderRadius: '8px', padding: '10px 12px', margin: '4px 0 16px' },
  submitBtn: { width: '100%', padding: '13px', background: '#1A1A1A', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '15px', fontWeight: '700', cursor: 'pointer', marginTop: '4px' },
  switchText: { textAlign: 'center', fontSize: '13px', color: '#666', marginTop: '22px' },
  switchBtn: { background: 'none', border: 'none', color: '#4A6FA5', fontWeight: '700', fontSize: '13px', cursor: 'pointer', padding: 0 },
  backLink: { display: 'block', textAlign: 'center', marginTop: '18px', fontSize: '13px', color: '#AAA', textDecoration: 'none' },
};
