import { useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import products from '../data/products';

export default function ProductDetail({ onAddToCart }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [added, setAdded] = useState(false);
  const product = products.find(p => p.id === parseInt(id));

  if (!product) return (
    <div style={styles.notFound}>
      <h2>Product not found</h2>
      <Link to="/catalog">← Back to Catalog</Link>
    </div>
  );

  const related = products.filter(p => p.category === product.category && p.id !== product.id).slice(0, 3);

  const handleAdd = () => {
    onAddToCart(product);
    setAdded(true);
    setTimeout(() => setAdded(false), 1800);
  };

  return (
    <div style={styles.page}>
      <Link to="/catalog" style={styles.back}>← Back to Catalog</Link>

      <div style={styles.main}>
        <div style={styles.imgWrap}>
          <img src={product.image} alt={product.name} style={styles.img} />
        </div>
        <div style={styles.details}>
          <span style={styles.category}>{product.category}</span>
          <h1 style={styles.name}>{product.name}</h1>
          <p style={styles.price}>${product.price.toFixed(2)}</p>
          <p style={styles.desc}>{product.description}</p>
          <button onClick={handleAdd} style={{ ...styles.addBtn, background: added ? '#2E7D32' : '#4A6FA5' }}>
            {added ? '✓ Added to Cart' : 'Add to Cart'}
          </button>
          <button onClick={() => { onAddToCart(product); navigate('/cart'); }} style={styles.buyBtn}>
            Buy Now
          </button>
        </div>
      </div>

      {related.length > 0 && (
        <div style={styles.related}>
          <h3 style={styles.relTitle}>More from {product.category}</h3>
          <div style={styles.relGrid}>
            {related.map(p => (
              <Link to={`/product/${p.id}`} key={p.id} style={styles.relCard}>
                <img src={p.image} alt={p.name} style={styles.relImg} />
                <p style={styles.relName}>{p.name}</p>
                <p style={styles.relPrice}>${p.price.toFixed(2)}</p>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

const styles = {
  page: { padding: '32px 48px' },
  back: { color: '#4A6FA5', textDecoration: 'none', fontSize: '14px', fontWeight: '500', display: 'inline-block', marginBottom: '28px' },
  main: { display: 'flex', gap: '60px', alignItems: 'flex-start', marginBottom: '56px' },
  imgWrap: { flex: 1, borderRadius: '12px', overflow: 'hidden', maxWidth: '500px' },
  img: { width: '100%', aspectRatio: '1', objectFit: 'cover' },
  details: { flex: 1, paddingTop: '8px' },
  category: { display: 'inline-block', background: '#E8EDF5', color: '#4A6FA5', padding: '4px 12px', borderRadius: '20px', fontSize: '12px', fontWeight: '600', marginBottom: '16px' },
  name: { fontFamily: "'Playfair Display', serif", fontSize: '36px', fontWeight: '700', color: '#1A1A1A', margin: '0 0 16px', lineHeight: 1.2 },
  price: { fontSize: '28px', fontWeight: '700', color: '#4A6FA5', margin: '0 0 24px' },
  desc: { color: '#555', fontSize: '16px', lineHeight: 1.7, margin: '0 0 32px', maxWidth: '440px' },
  addBtn: { display: 'block', width: '100%', padding: '14px', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '15px', fontWeight: '600', cursor: 'pointer', marginBottom: '12px', transition: 'background 0.3s' },
  buyBtn: { display: 'block', width: '100%', padding: '14px', background: '#fff', color: '#1A1A1A', border: '1.5px solid #1A1A1A', borderRadius: '8px', fontSize: '15px', fontWeight: '600', cursor: 'pointer' },
  related: { borderTop: '1px solid #EBEBEB', paddingTop: '40px' },
  relTitle: { fontFamily: "'Playfair Display', serif", fontSize: '22px', fontWeight: '700', color: '#1A1A1A', marginBottom: '24px' },
  relGrid: { display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px' },
  relCard: { textDecoration: 'none', color: 'inherit', borderRadius: '10px', overflow: 'hidden', border: '1px solid #EBEBEB' },
  relImg: { width: '100%', aspectRatio: '1', objectFit: 'cover' },
  relName: { padding: '10px 12px 4px', fontSize: '14px', fontWeight: '600', color: '#1A1A1A', margin: 0 },
  relPrice: { padding: '0 12px 12px', fontSize: '14px', color: '#4A6FA5', fontWeight: '700', margin: 0 },
  notFound: { textAlign: 'center', padding: '80px' },
};
