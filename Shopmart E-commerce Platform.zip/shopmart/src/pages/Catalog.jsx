import { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import products from '../data/products';
import ProductCard from '../components/ProductCard';

const CATEGORIES = ['All', 'Home', 'Accessories', 'Stationery', 'Tech', 'Kitchen'];

export default function Catalog({ onAddToCart }) {
  const location = useLocation();
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [sort, setSort] = useState('default');

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const cat = params.get('category');
    if (cat) setCategory(cat);
  }, [location.search]);

  let filtered = products.filter(p => {
    const matchCat = category === 'All' || p.category === category;
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase());
    return matchCat && matchSearch;
  });

  if (sort === 'low') filtered = [...filtered].sort((a, b) => a.price - b.price);
  if (sort === 'high') filtered = [...filtered].sort((a, b) => b.price - a.price);
  if (sort === 'name') filtered = [...filtered].sort((a, b) => a.name.localeCompare(b.name));

  return (
    <div style={styles.page}>
      <div style={styles.header}>
        <h1 style={styles.title}>All Products</h1>
        <p style={styles.count}>{filtered.length} items</p>
      </div>

      {/* Filters */}
      <div style={styles.toolbar}>
        <div style={styles.catRow}>
          {CATEGORIES.map(cat => (
            <button key={cat} onClick={() => setCategory(cat)}
              style={{ ...styles.catBtn, ...(category === cat ? styles.catActive : {}) }}>
              {cat}
            </button>
          ))}
        </div>
        <div style={styles.rightTools}>
          <input type="text" placeholder="Search products..." value={search}
            onChange={e => setSearch(e.target.value)} style={styles.search} />
          <select value={sort} onChange={e => setSort(e.target.value)} style={styles.select}>
            <option value="default">Sort: Default</option>
            <option value="low">Price: Low to High</option>
            <option value="high">Price: High to Low</option>
            <option value="name">Name A–Z</option>
          </select>
        </div>
      </div>

      {/* Grid */}
      {filtered.length === 0 ? (
        <div style={styles.empty}>
          <p style={styles.emptyTitle}>No products found</p>
          <p style={styles.emptySub}>Try adjusting your search or category filter.</p>
        </div>
      ) : (
        <div style={styles.grid}>
          {filtered.map(p => <ProductCard key={p.id} product={p} onAddToCart={onAddToCart} />)}
        </div>
      )}
    </div>
  );
}

const styles = {
  page: { padding: '40px 48px', minHeight: '70vh' },
  header: { display: 'flex', alignItems: 'baseline', gap: '16px', marginBottom: '28px' },
  title: { fontFamily: "'Playfair Display', serif", fontSize: '32px', fontWeight: '700', color: '#1A1A1A', margin: 0 },
  count: { color: '#888', fontSize: '14px' },
  toolbar: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '32px', gap: '16px', flexWrap: 'wrap' },
  catRow: { display: 'flex', gap: '8px', flexWrap: 'wrap' },
  catBtn: { padding: '8px 18px', border: '1.5px solid #E0E0E0', borderRadius: '30px', background: '#fff', fontSize: '13px', fontWeight: '500', cursor: 'pointer', color: '#555', transition: 'all 0.2s' },
  catActive: { background: '#1A1A1A', color: '#fff', borderColor: '#1A1A1A' },
  rightTools: { display: 'flex', gap: '10px', alignItems: 'center' },
  search: { padding: '9px 16px', border: '1.5px solid #E0E0E0', borderRadius: '8px', fontSize: '14px', outline: 'none', width: '200px', background: '#fff' },
  select: { padding: '9px 14px', border: '1.5px solid #E0E0E0', borderRadius: '8px', fontSize: '13px', background: '#fff', cursor: 'pointer' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: '24px' },
  empty: { textAlign: 'center', padding: '80px 0' },
  emptyTitle: { fontSize: '20px', fontWeight: '600', color: '#1A1A1A', margin: '0 0 8px' },
  emptySub: { color: '#888', fontSize: '15px' },
};
