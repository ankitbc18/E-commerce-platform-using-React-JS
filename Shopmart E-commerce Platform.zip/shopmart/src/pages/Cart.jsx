import { Link, useNavigate } from 'react-router-dom';

export default function Cart({ cart, onRemove, onUpdateQty, totalPrice }) {
  const navigate = useNavigate();

  if (cart.length === 0) return (
    <div style={styles.empty}>
      <div style={styles.emptyIcon}>🛒</div>
      <h2 style={styles.emptyTitle}>Your cart is empty</h2>
      <p style={styles.emptySub}>Looks like you haven't added anything yet.</p>
      <Link to="/catalog" style={styles.shopBtn}>Start Shopping</Link>
    </div>
  );

  return (
    <div style={styles.page}>
      <h1 style={styles.title}>Your Cart</h1>

      <div style={styles.layout}>
        <div style={styles.items}>
          {cart.map(item => (
            <div key={item.id} style={styles.item}>
              <img src={item.image} alt={item.name} style={styles.img} />
              <div style={styles.info}>
                <p style={styles.name}>{item.name}</p>
                <p style={styles.cat}>{item.category}</p>
                <p style={styles.unitPrice}>${item.price.toFixed(2)} each</p>
              </div>
              <div style={styles.qtyRow}>
                <button style={styles.qBtn} onClick={() => onUpdateQty(item.id, item.qty - 1)}>−</button>
                <span style={styles.qty}>{item.qty}</span>
                <button style={styles.qBtn} onClick={() => onUpdateQty(item.id, item.qty + 1)}>+</button>
              </div>
              <p style={styles.subtotal}>${(item.price * item.qty).toFixed(2)}</p>
              <button style={styles.remove} onClick={() => onRemove(item.id)}>✕</button>
            </div>
          ))}
        </div>

        <div style={styles.summary}>
          <h3 style={styles.sumTitle}>Order Summary</h3>
          <div style={styles.sumRow}><span>Subtotal</span><span>${totalPrice.toFixed(2)}</span></div>
          <div style={styles.sumRow}><span>Shipping</span><span style={{ color: '#2E7D32' }}>Free</span></div>
          <div style={styles.divider} />
          <div style={{ ...styles.sumRow, fontWeight: '700', fontSize: '18px', color: '#1A1A1A' }}>
            <span>Total</span><span>${totalPrice.toFixed(2)}</span>
          </div>
          <button onClick={() => navigate('/checkout')} style={styles.checkoutBtn}>
            Proceed to Checkout
          </button>
          <Link to="/catalog" style={styles.continueLink}>← Continue Shopping</Link>
        </div>
      </div>
    </div>
  );
}

const styles = {
  page: { padding: '40px 48px' },
  title: { fontFamily: "'Playfair Display', serif", fontSize: '32px', fontWeight: '700', color: '#1A1A1A', marginBottom: '32px' },
  layout: { display: 'flex', gap: '40px', alignItems: 'flex-start' },
  items: { flex: 2, display: 'flex', flexDirection: 'column', gap: '16px' },
  item: { display: 'flex', alignItems: 'center', gap: '20px', background: '#fff', padding: '16px', borderRadius: '10px', border: '1px solid #EBEBEB' },
  img: { width: '72px', height: '72px', objectFit: 'cover', borderRadius: '8px' },
  info: { flex: 1 },
  name: { margin: '0 0 4px', fontWeight: '600', fontSize: '15px', color: '#1A1A1A' },
  cat: { margin: '0 0 4px', fontSize: '12px', color: '#888' },
  unitPrice: { margin: 0, fontSize: '13px', color: '#666' },
  qtyRow: { display: 'flex', alignItems: 'center', gap: '10px', background: '#F5F5F5', borderRadius: '8px', padding: '6px 12px' },
  qBtn: { background: 'none', border: 'none', fontSize: '16px', cursor: 'pointer', color: '#1A1A1A', fontWeight: '700', lineHeight: 1 },
  qty: { fontSize: '15px', fontWeight: '600', minWidth: '20px', textAlign: 'center' },
  subtotal: { fontWeight: '700', color: '#4A6FA5', minWidth: '70px', textAlign: 'right', margin: 0 },
  remove: { background: 'none', border: 'none', color: '#CCC', cursor: 'pointer', fontSize: '16px', padding: '4px' },
  summary: { flex: 1, background: '#fff', border: '1px solid #EBEBEB', borderRadius: '12px', padding: '28px', position: 'sticky', top: '80px' },
  sumTitle: { fontSize: '18px', fontWeight: '700', color: '#1A1A1A', marginBottom: '20px' },
  sumRow: { display: 'flex', justifyContent: 'space-between', marginBottom: '14px', fontSize: '15px', color: '#555' },
  divider: { borderTop: '1px solid #EBEBEB', margin: '16px 0' },
  checkoutBtn: { width: '100%', padding: '14px', background: '#4A6FA5', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '15px', fontWeight: '600', cursor: 'pointer', marginTop: '20px', marginBottom: '12px' },
  continueLink: { display: 'block', textAlign: 'center', color: '#666', fontSize: '13px', textDecoration: 'none' },
  empty: { textAlign: 'center', padding: '100px 48px' },
  emptyIcon: { fontSize: '56px', marginBottom: '16px' },
  emptyTitle: { fontFamily: "'Playfair Display', serif", fontSize: '28px', color: '#1A1A1A', margin: '0 0 8px' },
  emptySub: { color: '#888', fontSize: '16px', marginBottom: '28px' },
  shopBtn: { display: 'inline-block', background: '#1A1A1A', color: '#fff', padding: '14px 32px', borderRadius: '8px', textDecoration: 'none', fontSize: '15px', fontWeight: '600' },
};
