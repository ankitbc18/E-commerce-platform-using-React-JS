# Shopmart — React E-Commerce Store

Shopmart is a responsive React-based e-commerce storefront for browsing and purchasing curated everyday products. Users can explore products, search and filter the catalog, view product details, manage a persistent shopping cart, create/login to an account, and complete a validated checkout flow.

## Features Implemented

- Home page with:
  - Hero section
  - Shop-by-category navigation
  - Featured products
- Product catalog with 12 products across 5 categories:
  - Home
  - Accessories
  - Stationery
  - Tech
  - Kitchen
- Product search by name
- Category filtering
- Product sorting:
  - Default
  - Price: Low to High
  - Price: High to Low
  - Name A–Z
- Product detail pages with:
  - Product image
  - Category
  - Price
  - Description
  - Add to Cart
  - Buy Now
  - Related products
- Shopping cart with:
  - Add/remove products
  - Increase/decrease quantity
  - Automatic subtotal and total calculation
  - Cart item count badge
  - Free shipping display
- Cart persistence using browser `localStorage`
- User authentication UI:
  - Sign up
  - Sign in
  - Log out
  - Session persistence using `localStorage`
  - Basic form validation
- Checkout page with:
  - Shipping details
  - Payment form
  - Client-side validation
  - Order summary
  - Order confirmation screen
- Client-side routing using React Router
- Responsive product grids and layout styling

## Technologies / Libraries Used

- **React 19** — UI development using functional components and hooks
- **React DOM 19** — Rendering the React application
- **React Router DOM 7** — Client-side page routing
- **React Scripts 5** — Development server and build tooling
- **JavaScript (ES6+)** — Application logic
- **CSS / Inline React Styles** — User interface styling
- **Browser localStorage** — Cart, user, and session persistence
- **Google Fonts** — Inter and Playfair Display
- **Unsplash** — Product and hero images
- **Testing Library** — React testing dependencies included in the project

## Project Structure

```text
shopmart/
├── public/
├── src/
│   ├── components/
│   │   ├── Navbar.jsx
│   │   └── ProductCard.jsx
│   ├── data/
│   │   └── products.js
│   ├── hooks/
│   │   ├── useAuth.js
│   │   └── useCart.js
│   ├── pages/
│   │   ├── Home.jsx
│   │   ├── Catalog.jsx
│   │   ├── ProductDetail.jsx
│   │   ├── Cart.jsx
│   │   ├── Checkout.jsx
│   │   └── Login.jsx
│   ├── App.js
│   ├── App.css
│   └── index.css
├── docs/
│   └── screenshots/
├── package.json
└── README.md
```

## Setup Instructions

### 1. Open the project folder

```bash
cd shopmart
```

### 2. Install dependencies

```bash
npm install
```

### 3. Start the development server

```bash
npm start
```

The application normally opens at:

```text
http://localhost:3000
```

### 4. Create a production build (optional)

```bash
npm run build
```

## Screenshots

Add at least three screenshots of the **running application** to the `docs/screenshots/` folder and keep the filenames below:

### 1. Home Page

![Shopmart Home Page](docs/screenshots/home.png)

### 2. Product Catalog

![Shopmart Product Catalog](docs/screenshots/catalog.png)

### 3. Cart / Checkout

![Shopmart Cart or Checkout](docs/screenshots/cart-checkout.png)

> **Screenshot note:** The uploaded project did not include screenshots, and the application could not be launched in the documentation environment because its npm dependencies were not bundled. Replace the three screenshot placeholders above with screenshots captured after running `npm install` and `npm start`.

## Known Limitations

- There is no real backend API; product data is stored locally in `src/data/products.js`.
- Payment processing is simulated. The checkout form validates card details but does not process a real payment.
- User accounts are stored in browser `localStorage`; this is suitable for a course/demo project but is not secure enough for a production authentication system.
- Product images are loaded from Unsplash URLs, so an internet connection may be required for all images to display.
- There is no real order database or order-history system.
- Inventory/stock management is not implemented.
- The project does not include an admin dashboard.

## Available npm Scripts

| Command | Purpose |
|---|---|
| `npm start` | Starts the React development server |
| `npm run build` | Creates a production build |
| `npm test` | Runs the test suite |
| `npm run eject` | Ejects the Create React App configuration |

## Pages

| Page | Route | Purpose |
|---|---|---|
| Home | `/` | Hero, categories, and featured products |
| Catalog | `/catalog` | Browse, search, filter, and sort products |
| Product Detail | `/product/:id` | View individual product information |
| Cart | `/cart` | Manage cart items and view totals |
| Checkout | `/checkout` | Enter shipping/payment details and place an order |
| Login / Signup | `/login` | Create an account or sign in |

## Conclusion

Shopmart demonstrates the main functionality of a modern front-end e-commerce application using React, React Router, reusable components, custom hooks, client-side validation, and browser localStorage.
