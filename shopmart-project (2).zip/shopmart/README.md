# Shopmart — React Course Project

A minimal, aesthetic e-commerce product catalog and cart built with React.js.

## Features
- Browse 12 products across 5 categories (Home, Accessories, Stationery, Tech, Kitchen)
- Filter by category and search by name
- Sort products by price or name
- View full product details with related products
- Add to cart, update quantities, remove items
- Running cart total with item count badge
- Checkout form with client-side validation
- Cart persisted to localStorage (survives page refresh)
- React Router for 5 distinct pages

## Technologies
- React 18 (functional components + hooks)
- React Router v6
- localStorage for cart persistence
- Google Fonts (Inter + Playfair Display)
- Unsplash for product images

## Setup
```bash
npm install
npm start
```

## Pages
1. **Home** — Hero section + category pills + featured products
2. **Catalog** — Full product grid with filter/search/sort
3. **Product Detail** — Full details + related products
4. **Cart** — Item list + order summary
5. **Checkout** — Shipping + payment form with validation

## Known Limitations
- No real payment processing (mock form only)
- Product data is local mock data (no backend API)
